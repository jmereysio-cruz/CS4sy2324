public class Athlete{

String name, team;
double fgp;

public Athlete(String name,String team, double fgp){
  this.name = name;
  this.team = team;
  this.fgp = fgp;
}

  
public void changeTeam(String newTeam)  {
  team=newTeam;
}

public void makeShots(double increase){
    salary += increase;
  }

  }



public class Song{

  String title, artist;
  int splays;



  public Song(String title,String artist, int splays){
  this.title = title;
  this.artist = artist;
  this.splay = splay;
  }

    public Song(String title,String artist){
  this.title = title;
  this.artist = artist;
    }

    public Song(String title){
  this.title = title;
    }


  public String getArtist(){
    return artist;
  }

  public String getTitle(){
    return title;
  }
  public int getPlays{
    return splay;
  }
  
    
    
  }
}



